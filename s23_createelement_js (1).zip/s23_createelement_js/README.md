# s23_createElement_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/valeria-garcia017/pen/XJdxdwg](https://codepen.io/valeria-garcia017/pen/XJdxdwg).

